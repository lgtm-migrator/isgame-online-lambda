rm -rf index.zip
zip -X -r index.zip *
aws lambda update-function-code --function-name isGameOnline --zip-file fileb://index.zip
