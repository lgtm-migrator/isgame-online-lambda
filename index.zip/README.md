# isgame-online-lambda
Alexa Backend lambda API to parse and handle the request for status and next patch information for ISGAME.ONLINE

